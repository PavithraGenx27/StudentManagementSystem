﻿using System;
using System.Collections.Generic;
using System.Linq;

class StudentManagementSystem
{
    static List<string> studentNames = new List<string>();
    static Dictionary<string, double> studentGrades = new Dictionary<string, double>();

    static void Main()
    {
        while (true)
        {
            Console.WriteLine("\n--- Student Management System ---");
            Console.WriteLine("1. Add Student");
            Console.WriteLine("2. View All Students");
            Console.WriteLine("3. Update Student Grade");
            Console.WriteLine("4. Delete Student");
            Console.WriteLine("5. Search Student");
            Console.WriteLine("6. Filter Students by Grade");
            Console.WriteLine("7. Exit");
            Console.Write("Choose an option (1-7): ");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    AddStudent();
                    break;
                case "2":
                    ViewAllStudents();
                    break;
                case "3":
                    UpdateStudent();
                    break;
                case "4":
                    DeleteStudent();
                    break;
                case "5":
                    SearchStudent();
                    break;
                case "6":
                    FilterByGrade();
                    break;
                case "7":
                    Console.WriteLine("Exiting program.");
                    return;
                default:
                    Console.WriteLine("Invalid choice. Try again.");
                    break;
            }
        }
    }

    static void AddStudent()
    {
        Console.Write("Enter student name: ");
        string name = Console.ReadLine().Trim();

        if (studentGrades.ContainsKey(name))
        {
            Console.WriteLine("Student already exists.");
            return;
        }

        Console.Write("Enter grade: ");
        if (double.TryParse(Console.ReadLine(), out double grade))
        {
            studentNames.Add(name);
            studentGrades[name] = grade;
            Console.WriteLine("Student added.");
        }
        else
        {
            Console.WriteLine("Invalid grade input.");
        }
    }

    static void ViewAllStudents()
    {
        if (studentNames.Count == 0)
        {
            Console.WriteLine("No students found.");
            return;
        }

        Console.WriteLine("\nStudent List:");
        foreach (string name in studentNames)
        {
            Console.WriteLine($"{name} - Grade: {studentGrades[name]}");
        }
    }

    static void UpdateStudent()
    {
        Console.Write("Enter student name to update: ");
        string name = Console.ReadLine().Trim();

        if (studentGrades.ContainsKey(name))
        {
            Console.Write("Enter new grade: ");
            if (double.TryParse(Console.ReadLine(), out double grade))
            {
                studentGrades[name] = grade;
                Console.WriteLine("Grade updated.");
            }
            else
            {
                Console.WriteLine("Invalid grade input.");
            }
        }
        else
        {
            Console.WriteLine("Student not found.");
        }
    }

    static void DeleteStudent()
    {
        Console.Write("Enter student name to delete: ");
        string name = Console.ReadLine().Trim();

        if (studentGrades.ContainsKey(name))
        {
            studentGrades.Remove(name);
            studentNames.Remove(name);
            Console.WriteLine("Student deleted.");
        }
        else
        {
            Console.WriteLine("Student not found.");
        }
    }

    static void SearchStudent()
    {
        Console.Write("Enter student name to search: ");
        string name = Console.ReadLine().Trim();

        if (studentGrades.ContainsKey(name))
        {
            Console.WriteLine($"{name} - Grade: {studentGrades[name]}");
        }
        else
        {
            Console.WriteLine("Student not found.");
        }
    }

    static void FilterByGrade()
    {
        Console.Write("Enter minimum grade to filter by: ");
        if (double.TryParse(Console.ReadLine(), out double minGrade))
        {
            var filtered = studentGrades.Where(s => s.Value >= minGrade);

            Console.WriteLine($"\nStudents with grade >= {minGrade}:");
            foreach (var student in filtered)
            {
                Console.WriteLine($"{student.Key} - Grade: {student.Value}");
            }
        }
        else
        {
            Console.WriteLine("Invalid input.");
        }
    }
}
